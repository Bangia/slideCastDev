package test;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.contactPageObjects;
import pageObjects.loginApp;

public class TC_0056 extends baseClass {
	
// TC_0056: Verify that Cross icon button functionality in search

	@Test
	public void startVoiceCall() throws InterruptedException, IOException {
		
		
		/*
		Back up script
		 System.setProperty("webdriver.chrome.driver", "/Users/hashstudioz/Desktop/chromedriver");
		WebDriver driver = new ChromeDriver();

		
		driver.get("https://dev.slidecast.com/login");
		driver.manage().window().maximize();
		 */
		
		logger.info("URL is opened");
		loginApp lp = new loginApp(driver);
		lp.setEmail(emailId_baseClass);
		logger.info("Entered username");
		lp.setPassword(password_baseClass);
		logger.info("Entered password");
		lp.clickBtn();
		logger.info("Submit Button clicked");
		driver.manage().timeouts().implicitlyWait(5000, TimeUnit.SECONDS);
		
		
		//Create contact link code starts here...
		contactPageObjects cpo = new contactPageObjects(driver);
		
		Thread.sleep(6000);
		
		cpo.contactLink();
		logger.info("Contact Link Clicked");
		
		driver.findElement(By.xpath("//div[@class='form-group float-left input-icon-panel col-sm-3']//input[@placeholder='Search']")).sendKeys("pandey12@gmail.com");
	
		
		WebElement crossIcon = driver.findElement(By.xpath("/html/body/app-root/body/app-contacts-v3/div/div[1]/div/div/div/div[1]/div[2]/div[1]/div/i"));
		
		
		if(crossIcon.isDisplayed()) {
			Thread.sleep(4000);
			crossIcon.click();
			logger.info("Data is cleaned test cased passed !!!");
			Thread.sleep(4000);
			driver.close();
			
		}
		else {
			logger.info("Data is Not cleaned test cased failed !!!");
		}
		
		
		
	}
	

}
