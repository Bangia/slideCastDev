package test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import pageObjects.loginApp;

public class TC_0011 extends baseClass {

/*

 TC_0011 : Verify Launch button should be clickable and able to start presentation and end presentation button.

*/


@Test
public void loginApps() throws InterruptedException  {
	
	/*
	Back up script
	 System.setProperty("webdriver.chrome.driver", "/Users/hashstudioz/Desktop/chromedriver");
	WebDriver driver = new ChromeDriver();

	
	driver.get("https://dev.slidecast.com/login");
	driver.manage().window().maximize();
	 */
	
	logger.info("URL is opened");
	//Create object of LoginApp
	loginApp lp = new loginApp(driver);
	
	lp.setEmail(emailId_baseClass);
	logger.info("email id entered");
	lp.setPassword(password_baseClass);
	logger.info("password entered");
	lp.clickBtn();
	logger.info("button clicked");
	

	
	driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
	
	System.out.println(driver.getTitle());
	
	
	String parentWindowhandle = driver.getWindowHandle();
	System.out.println("parentWindowhandle" + parentWindowhandle);
	logger.info("current windiw generated");
	//Click Launch Tab
	
	driver.findElement(By.xpath("//b[normalize-space()='Launch']")).click();
	logger.info("launch tab clicked");
	
	//Click Launch Button
	
	driver.findElement(By.xpath("//mat-row[1]//mat-cell[4]//button[1]")).click();
	logger.info("launch button clicked");
	
	
	
	for(String childTab: driver.getWindowHandles()) {
		driver.switchTo().window(childTab);
	}
	
	driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
	System.out.println("TITLE OF CHILD WINDOW"+driver.getTitle());	
	
	
	Thread.sleep(3000);

   driver.findElement(By.xpath("/html/body/app-root/body/div/app-sc-control/div/form/div[3]/div/div/div[9]/div/button[2]")).click();

	logger.info("start presentation clicked");
	
   
//	//Click end presentation button

driver.findElement(By.xpath("//button[normalize-space()='End Presentation']")).click();
logger.info("end presentation clicked");
 
driver.close();
	
}


}
