package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class presentationPageObjects {

WebDriver ldriver;
	
	//Initialise constructor
	public presentationPageObjects(WebDriver rdriver) {
		ldriver= rdriver;
		PageFactory.initElements(rdriver, this);
	}
	
	
	//Locator for help me build out 
	
	@FindBy(xpath="//b[normalize-space()='Presentations']")
	@CacheLookup
	WebElement presentationLink;
	
	@FindBy(xpath="/html/body/app-root/body/app-presentations-v3/div[1]/div[1]/div[2]/div[1]/div/div/div[1]/div[2]/button[2]")
	@CacheLookup
	WebElement helpBtn;
	
	@FindBy(xpath="//textarea[@formcontrolname='message']")
	@CacheLookup
	WebElement helpTextArea;
	
	@FindBy(xpath="//label[@for='enableImport']")
	@CacheLookup
	WebElement sendToggle;
	
	
	@FindBy(xpath="//label[contains(text(),'Select Files')]")
	@CacheLookup
	WebElement selectFiles;
	
	
	@FindBy(xpath="//label[contains(text(),'Reset')]")
	@CacheLookup
	WebElement ResetFiles;
	
	@FindBy(xpath="//button[normalize-space()='Upload Files']")
	@CacheLookup
	WebElement uploadFiles;
	
	@FindBy(xpath="//button[@class='btn btn-controls btn-selected configbutton']")
	@CacheLookup
	WebElement helpMeSubmitBtn;
	
	
	//Locator for blank template
	
	@FindBy(xpath="//mat-icon[normalize-space()='add']")
	@CacheLookup
	WebElement addIcon;
	
	@FindBy(xpath="//div[@class='build-new-box']//div[2]")
	@CacheLookup
	WebElement blankTemplate;
	
	@FindBy(xpath="//input[@id='name']")
	@CacheLookup
	WebElement presentationNameTxt;
	
	@FindBy(xpath="//button[normalize-space()='Save Presentation']")
	@CacheLookup
	WebElement savePresentation;
	
	@FindBy(xpath="/html/body/app-root/body/app-nav-menu-v3/div[1]/header/nav/div[2]/div[1]/div")
	@CacheLookup
	WebElement breadCrumBack;
	
	
	//Locator for select a template
	
	@FindBy(xpath="//div[@class='build-template'][normalize-space()='Select a Template']")
	@CacheLookup
	WebElement selectATemplate;
	
	@FindBy(xpath="//div[@class='card']//div[3]//div[1]//img[1]")
	@CacheLookup
	WebElement SelectImage;
	
	
	@FindBy(xpath="/html/body/app-root/body/app-presentations-v3/div[1]/div[1]/div[2]/div[1]/div/div/div[4]/div[1]/div/div[1]/button/span[1]/mat-icon")
	@CacheLookup
	WebElement mattIcon;
	
	@FindBy(xpath="//span[contains(text(),'Settings')]")
	@CacheLookup
	WebElement setIcon;
	
	@FindBy(xpath="//span[contains(text(),'Duplicate')]")
	@CacheLookup
	WebElement duplicateIcon;
	
	
	@FindBy(xpath="//span[contains(text(),'Yes')]")
	@CacheLookup
	WebElement yesIcon;
	
	@FindBy(xpath="//span[contains(text(),'Copy')]")
	@CacheLookup
	WebElement CopyLink;
	
	@FindBy(xpath="//span[normalize-space()='Delete']")
	@CacheLookup
	WebElement deleteLink;
	
	//Action method for help me build out 
	
	public void presentationLinkClick() {
		presentationLink.click();
	}
	
	public void helpButton() {
		helpBtn.click();	
	}
	
	public void helpTextAreaField(String textAreaText) {
		helpTextArea.sendKeys(textAreaText);
	}
	
	public void toggleEnable() {
		sendToggle.click();
	}
	
	public void selectFilesfield() {
		uploadFiles.sendKeys("/Users/hashstudioz/eclipse-workspace/slideCast/TestingUploadFiles");
	}
	
	public void resetButton() {
		ResetFiles.click();
	}
	
	public void uploadbtn() {
		uploadFiles.click();
	}
	
	public void helpMeButtonSubmit() {
		helpMeSubmitBtn.click();
	}
	
	public void addIconClick() {
		addIcon.click();
	}
	
	public void blankTemplateClick() {
		blankTemplate.click();
	}
		
	public void presentationTextBox(String ppt) throws InterruptedException {
		presentationNameTxt.clear();
		Thread.sleep(3000);
		presentationNameTxt.sendKeys(ppt);
	}
	
	public void saveMyPresentation() {
		savePresentation.click();
	}
	
	public void backToDashPptpage() {
		breadCrumBack.click();
	}
	
	public void selectATemplateLink() {
		selectATemplate.click();
	}
	
	public void SelectImage() {
		SelectImage.click();
	}
	
	public void hamicon() {
		mattIcon.click();
	}
	
	public void settingIcon() {
		setIcon.click();
	}
	
	public void dupeLink() {
		duplicateIcon.click();
	}
	
	public void yesButton() {
		yesIcon.click();
	}
	
	public void copyButton() {
		CopyLink.click();
	}
	
	public void deleteButton() {
		deleteLink.click();
	}
	
	
	
	
	
}
