package test;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import pageObjects.loginApp;

public class TC_0005 extends baseClass {

//	TC_0005 : verify that forget password --> Cancel button should be clickable
	
	@Test
	public void forgetPasswordLinkCancelButton() throws InterruptedException {
		/*
		Back up script
		 System.setProperty("webdriver.chrome.driver", "/Users/hashstudioz/Desktop/chromedriver");
		WebDriver driver = new ChromeDriver();

		
		driver.get("https://dev.slidecast.com/login");
		driver.manage().window().maximize();
		 */
		logger.info("URL is opened");
		
		loginApp lp = new loginApp(driver);
		lp.forgetLink();
		logger.info("Forget password link clicked");
		
		
		driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
		lp.setForgetPasswordText(emailId_baseClass);
		logger.info("email id entered");
		lp.forgetCancelButton();
		logger.info("cancel button clicked");
		
		Assert.assertTrue(true);
		System.out.println("Cancel Button Clicked test cases passed");
		
		Thread.sleep(8000);
		driver.close();
		
	}
	
	
	

}
