package test;

import java.util.concurrent.TimeUnit;

import org.testng.*;
import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import pageObjects.loginApp;
import pageObjects.profilePageObjects;

public class TC_0022 extends baseClass {
// TC_0022 : Verify able to click logout button
	
	@Test
	public void VerifyLogoutLink() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "/Users/hashstudioz/Desktop/chromedriver");
		WebDriver driver = new ChromeDriver();

		
		driver.get("https://dev.slidecast.com/login");
		driver.manage().window().maximize();
		
		loginApp lp = new loginApp(driver);
		lp.setEmail(emailId_baseClass);
		lp.setPassword(password_baseClass);
		lp.clickBtn();
		
		driver.manage().timeouts().implicitlyWait(6000, TimeUnit.SECONDS);
		
		
		profilePageObjects ppo = new profilePageObjects(driver);
		ppo.profileclick();
		ppo.lgtLink();
		
		String ActualURL = driver.getCurrentUrl();
		System.out.println(ActualURL);
		
		String ExpectedURL = "https://dev.slidecast.com/login";
		
		//assertion validation
		
		if(ActualURL.equals(ExpectedURL)) {
			Assert.assertTrue(true);
			System.out.println("TEST CASE PASSED PAGE NAVIGATED TO LOGIN PAGE !!!");
		}
		else {
			Assert.assertTrue(false);
			System.out.println("TEST CASE FAILED PAGE NOT NAVIGATED TO LOGIN PAGE !!!");
		}
		
		Thread.sleep(4000);
		driver.close();
		
	
		
		
	}
	
	
	
	

}
