package test;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import pageObjects.loginApp;
import pageObjects.profilePageObjects;

public class TC_0020 extends baseClass {

// TC_0020 : verify able to Edit profile.
	
	@Test
	public void ValidateProfileUpdate() throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "/Users/hashstudioz/Desktop/chromedriver");
		WebDriver driver = new ChromeDriver();

		
		driver.get("https://dev.slidecast.com/login");
		driver.manage().window().maximize();
		
		loginApp lp = new loginApp(driver);
		lp.setEmail(emailId_baseClass);
		lp.setPassword(password_baseClass);
		lp.clickBtn();
		
		driver.manage().timeouts().implicitlyWait(10000, TimeUnit.SECONDS);
		
		//Profile update code starts here...
		
		profilePageObjects ppo = new profilePageObjects(driver);
		
		Thread.sleep(5000);
		ppo.profileclick();
		ppo.profileEdtLink();
		Thread.sleep(3000);
		ppo.FirstName("Nitins");
		Thread.sleep(3000);
		ppo.LastName("Bangia");
		Thread.sleep(3000);
		ppo.Mobile("9711718149");
		Thread.sleep(3000);
		ppo.Email("nitinbangia8@gmail.com");
		Thread.sleep(3000);
		
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("window.scrollBy(0,250)");
		
		ppo.Address1("Noida");
		Thread.sleep(3000);
		ppo.Address2("Noida");
		Thread.sleep(3000);
		ppo.Address3("Noida");
		Thread.sleep(3000);
		ppo.cityName("Uttar Pradesh");
		Thread.sleep(3000);
		ppo.zipCodetxt("201301");
		Thread.sleep(3000);
		ppo.saveButton();
		
		Assert.assertTrue(true);
		
		Thread.sleep(3000);
		
		driver.close();
		
	}
	
	
}
