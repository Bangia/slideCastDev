package test;

import java.io.IOException;
import java.util.concurrent.TimeUnit;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.sun.tools.sjavac.Log;

import pageObjects.contactPageObjects;
import pageObjects.loginApp;


public class TC_0007 extends baseClass {

/*
TC_0007 : "Verify that application should validation message if User try to save blank contact 
i.e. without First name & Last name	
*/
	@Test
	public void ContactValidation() throws InterruptedException, IOException {
		/*
		Back up script
		 System.setProperty("webdriver.chrome.driver", "/Users/hashstudioz/Desktop/chromedriver");
		WebDriver driver = new ChromeDriver();

		
		driver.get("https://dev.slidecast.com/login");
		driver.manage().window().maximize();
		 */
		
		logger.info("URL is opened");
		loginApp lp = new loginApp(driver);
		lp.setEmail(emailId_baseClass);
		logger.info("Entered username");
		lp.setPassword(password_baseClass);
		logger.info("Entered password");
		lp.clickBtn();
		logger.info("Submit Button clicked");
		driver.manage().timeouts().implicitlyWait(5000, TimeUnit.SECONDS);
		
		
		//Create contact link code starts here...
		contactPageObjects cpo = new contactPageObjects(driver);
		
		Thread.sleep(6000);
		
		cpo.contactLink();
		logger.info("Contact Link Clicked");
		
		Thread.sleep(5000);
		cpo.createContactButton();
		
		logger.info("create contact button clicked");
		
		cpo.UpperSaveBtn();
		logger.info("Upper save button clicked");
		
		//validation assertion starts here...
		String ActualFirstName = driver.findElement(By.xpath("//div[contains(text(),'First Name is required')]")).getText();
		
		System.out.print("ActualFirstName"+ActualFirstName);
		
		String ExpectedFirstName ="First Name is required";
		String ExpectedLastName ="Last Name is required";
		
		String ActualLastName = driver.findElement(By.xpath("//div[contains(text(),'Last Name is required')]")).getText();
		
		System.out.print("ActualLastName" + ActualLastName);
		
		if(ActualFirstName.equals(ExpectedFirstName) && ActualLastName.equals(ExpectedLastName)) {
			Assert.assertTrue(true);
			logger.info("Test case passed validation message shown");
			Thread.sleep(8000);
			driver.close();
		}
		else {
			captureScreen(driver,"TC_0007");
			Assert.assertTrue(false);
			logger.error("TC_0007 - Test cases failed");
			
		}
		
		
		
	
		
		
	
	
	
	}

	
	

}
