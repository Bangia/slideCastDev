package test;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.SupportPageObjects;
import pageObjects.loginApp;

public class TC_0031 extends baseClass{

	@Test
	public void SupporQuerySend() throws InterruptedException, IOException {
		/*
		Back up script
		 System.setProperty("webdriver.chrome.driver", "/Users/hashstudioz/Desktop/chromedriver");
		WebDriver driver = new ChromeDriver();

		
		driver.get("https://dev.slidecast.com/login");
		driver.manage().window().maximize();
		 */
		
		logger.info("URL is opened");
		
		loginApp lp = new loginApp(driver);
		lp.setEmail(emailId_baseClass);
		logger.info("Entered username");
		
		lp.setPassword(password_baseClass);
		logger.info("Entered password");
		
		lp.clickBtn();
		logger.info("Button is Clicked !!!");
		
		driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
		
		//Support Page Object called
		
		SupportPageObjects spo = new SupportPageObjects(driver);
		
		spo.SupporticonClick();
		spo.SupportTxt(" This is FREE FLOW TEXT");
		
		//spo.arrowClick();
		Thread.sleep(4000);
		//spo.arrowValue();
		
		spo.SupportBtn();
		
		//Assertion
		
		
		String ActualMessage = driver.findElement(By.xpath("//div[@aria-label='Thank you']")).getText();
		System.out.println(ActualMessage);
		
		
		String expectedMessage = "Thank you";
		
		
		if(ActualMessage.equals(expectedMessage)) {
			Assert.assertTrue(true);
			logger.info("Support Query Send - Test Case Passed");
			Thread.sleep(8000);
			driver.close();
			
			
		}
		else {
			captureScreen(driver,"TC_0031");
			Assert.assertTrue(false);
			reportLog("Support Query Not Send - Test Case Failed");
			
			
		}
		
		
		
		
	}
	
	
}
