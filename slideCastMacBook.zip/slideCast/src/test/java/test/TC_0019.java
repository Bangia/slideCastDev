package test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.SupportPageObjects;
import pageObjects.loginApp;

public class TC_0019 extends baseClass {
	
	
	
//TC_0019 : verify that able to send support query.
	
	@Test
	public void supportQuery() throws InterruptedException {
		
		
		System.setProperty("webdriver.chrome.driver", "/Users/hashstudioz/Desktop/chromedriver");
		WebDriver driver = new ChromeDriver();

		
		driver.get("https://dev.slidecast.com/login");
		driver.manage().window().maximize();
		
		//Create object of LoginApp
		loginApp lp = new loginApp(driver);
		
		lp.setEmail(emailId_baseClass);
		lp.setPassword(password_baseClass);
		lp.clickBtn();
		
		//Support query code starts here....
		driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
		SupportPageObjects hpg = new SupportPageObjects(driver);
		
		driver.manage().timeouts().implicitlyWait(5000, TimeUnit.SECONDS);
		
		hpg.SupporticonClick();
		
		hpg.SupportTxt("Free flow text");
		
		
		
		//hpg.arrowClick();
		
		hpg.arrowValue();
		
		driver.findElement(By.xpath("//button[normalize-space()='Send your Support Request']")).click();
		
		String Actualmessage = driver.findElement(By.xpath("//div[@class='toast-info ngx-toastr ng-trigger ng-trigger-flyInOut']")).getText();
		System.out.println(Actualmessage);
		
		String expectedMessage = "Thank you Your request has been sent. We will get back to your shortly.";
		
		if(Actualmessage.contains("Thank you") && expectedMessage.contains("Thank you")) {
			Assert.assertTrue(true);
		}
		else {
			Assert.assertTrue(false);
		}
		//Assert.assertEquals(Actualmessage, expectedMessage, "Titles of the website do not match");
		
		Thread.sleep(4000);
		driver.close();
		
	}
	

}
