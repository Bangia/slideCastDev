package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class loginApp {

	WebDriver ldriver;
	
	//Initialise constructor
	public loginApp(WebDriver rdriver) {
		ldriver= rdriver;
		PageFactory.initElements(rdriver, this);
	}
	
	
	//Locators
	
	@FindBy(id="email")
	@CacheLookup
	WebElement txtEmail;
	
	@FindBy(id="password")
	@CacheLookup
	WebElement txtPassword;
	
	@FindBy(xpath="//button[@class='btn btn-lg btn-selected center']")
	@CacheLookup
	WebElement txtSubmit;
	
	
	//Locators of Click Launch Tab
	
		//Locators of Click Launch Button
		
		//Locators of Click see presentation button
		
		//Locators of Click end presentation button
	
	
	//Forget Password xpath
	@FindBy(xpath="//span[@class='clickable text-bold-small']")
	@CacheLookup
	WebElement forgetPasswordLinkClick;
	
	//Forget Password cancel button xpath
	@FindBy(xpath="//button[normalize-space()='Cancel']")
	@CacheLookup
	WebElement forgetCancelBtn;
	
	//Forget Password text field id
	@FindBy(id="emailr")
	@CacheLookup
	WebElement forgetPasswordTxt;
	
	//Forget Password click button
	@FindBy(xpath="//button[normalize-space()='Send Link']")
	@CacheLookup
	WebElement forgetPasswordClick;
	
	@FindBy(xpath="//*[@id='mat-radio-3']/label")
	@CacheLookup
	WebElement MobileRadio;
	
	
	@FindBy(xpath="//input[@formcontrolname='imobile']")
	@CacheLookup
	WebElement MobileField;
	
	@FindBy(id="password")
	@CacheLookup
	WebElement MobilePassword;
	
	@FindBy(xpath="//button[@class='btn btn-lg btn-selected center']")
	@CacheLookup
	WebElement MobileSubmitBtn;
	
	
	//Sign in with google starts here
	
	@FindBy(xpath="//div[@class='abcRioButtonContentWrapper']")
	@CacheLookup
	WebElement googleBtn;
	
	@FindBy(id="identifierId")
	@CacheLookup
	WebElement otherAccountClick;
	
	@FindBy(xpath="//span[contains(text(),'Next')]")
	@CacheLookup
	WebElement nxtClick;
	
	@FindBy(name="password")
	@CacheLookup
	WebElement passwordGmail;
	
	@FindBy(xpath="//*[contains(text(),'Next')]")
	@CacheLookup
	WebElement GmailContinue;
	
//****************************** Action Methods ************************************************************
	
	
	public void setEmail(String emailId) {
		txtEmail.sendKeys(emailId);
	}
	
	public void setPassword(String password) {
		txtPassword.sendKeys(password);
	}
	
	public void clickBtn() {
		txtSubmit.click();
	}
	
	//Click Launch Tab
	
	//Click Launch Button
	
	//Click see presentation button
	
	//Click end presentation button
	
	
	public void forgetLink() {
		forgetPasswordLinkClick.click();
	}
	
	public void forgetCancelButton() {
		forgetCancelBtn.click();
	}
	
	public void setForgetPasswordText(String emailForget) {
		forgetPasswordTxt.sendKeys(emailForget);
	}
	
	public void forgetSendLink() {
		forgetPasswordClick.click();
	}
	
	public void mobileRadioClick() {
		MobileRadio.click();
	}
	
	public void mobileNumbTxtField(String mobileNumber) {
		MobileField.sendKeys(mobileNumber);
		
	}
	
    public void mobilePwdTxtField(String mobilePwd) {
    	MobilePassword.sendKeys(mobilePwd);
	}
    
    public void mobileSbtBtn() {
    	MobileSubmitBtn.click();
   	}
	
    
  //Sign in with google starts here
    public void gmailButton() {
    	googleBtn.click();
    }
    
    public void emailIDTxt(String emails) {
    	otherAccountClick.sendKeys(emails);
    }
    
    public void nextButtonGmail() {
    	nxtClick.click();
    }
    
    public void Password_Gmail(String password) {
    	passwordGmail.sendKeys(password);
    }
	
}
