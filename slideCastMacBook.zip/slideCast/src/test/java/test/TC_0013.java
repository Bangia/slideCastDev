package test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import pageObjects.launchPageObjects;
import pageObjects.loginApp;

public class TC_0013 extends baseClass {
	
// 	TC_0013 : Launch : verify able to create contact using contact button
	
	@Test
	public void launchCreateContact() throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "/Users/hashstudioz/Desktop/chromedriver");
		WebDriver driver = new ChromeDriver();

		
		driver.get("https://dev.slidecast.com/login");
		driver.manage().window().maximize();
		
		//Create object of LoginApp
				loginApp lp = new loginApp(driver);
				
				lp.setEmail(emailId_baseClass);
				lp.setPassword(password_baseClass);
				lp.clickBtn();
		
		driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
		//Create object of launchPageObjects
		launchPageObjects lpo = new launchPageObjects(driver);
		lpo.launLinkText();
		
		Thread.sleep(3000);
		lpo.contactCreateBtn();
		
		
		String parentWindowhandle = driver.getWindowHandle();
		System.out.println("parentWindowhandle" + parentWindowhandle);
		
		//Name , last name , email id and mobile number will come dynamic from base class
		lpo.setFirstName("dEEPAK");
		lpo.setLastName("sharma");
		lpo.setEmail("deepak@yopmail.com");
		lpo.setMobile("9711718156");
		
		
		
		lpo.saveLaunchBtnClick();
	
		
		Thread.sleep(4000);
		
		for(String childTab: driver.getWindowHandles()) {
			driver.switchTo().window(childTab);
		}
		
		driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
		System.out.println("TITLE OF CHILD WINDOW"+driver.getTitle());	
		
		
		

	   driver.findElement(By.xpath("/html/body/app-root/body/div/app-sc-control/div/form/div[3]/div/div/div[9]/div/button[2]")).click();

 //Click end presentation button

	driver.findElement(By.xpath("//button[normalize-space()='End Presentation']")).click();
		
		
	}
	
	

}
