package test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import pageObjects.loginApp;

public class TC_0018 extends baseClass {
	
public static WebDriver driver;
	
//	TC_0018 : Verify on Top header launch button able to click
	
	
	@Test
	public void topHeaderLaunchButton() throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "/Users/hashstudioz/Desktop/chromedriver");
		WebDriver driver = new ChromeDriver();

		
		driver.get("https://dev.slidecast.com/login");
		driver.manage().window().maximize();
		
		//Create Object
		loginApp lp = new loginApp(driver);
		lp.setEmail(emailId_baseClass);
		lp.setPassword(password_baseClass);
		lp.clickBtn();
		
		driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
		
		System.out.println(driver.getTitle());
		
		
		String parentWindowhandle = driver.getWindowHandle();
		System.out.println("parentWindowhandle" + parentWindowhandle);
		
		driver.findElement(By.xpath("//button[@mattooltip='Select a Contact and launch your default presentation'][1]")).click();
		
		
		
		//Click Launch Button on Top Header
		
		driver.findElement(By.xpath("//mat-row[1]//mat-cell[4]//button[1]")).click();
		
		
		for(String childTab: driver.getWindowHandles()) {
			driver.switchTo().window(childTab);
		}
		
		driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
		System.out.println("TITLE OF CHILD WINDOW"+driver.getTitle());	
		
		
		Thread.sleep(3000);

	   driver.findElement(By.xpath("/html/body/app-root/body/div/app-sc-control/div/form/div[3]/div/div/div[9]/div/button[2]")).click();

    //Click End presentation button

	driver.findElement(By.xpath("//button[normalize-space()='End Presentation']")).click();

	 driver.close();
		
		
		
	}
	
	

}
