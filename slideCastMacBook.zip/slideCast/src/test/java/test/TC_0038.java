package test;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.contactPageObjects;
import pageObjects.loginApp;

public class TC_0038 extends baseClass {
// TC_0038: Contact Back button
	
	@Test
	public void contactBackButton() throws InterruptedException, IOException {
		
		/*
		Back up script
		 System.setProperty("webdriver.chrome.driver", "/Users/hashstudioz/Desktop/chromedriver");
		WebDriver driver = new ChromeDriver();

		
		driver.get("https://dev.slidecast.com/login");
		driver.manage().window().maximize();
		 */
		
		
		logger.info("URL is opened");
		
		loginApp lp = new loginApp(driver);
		lp.setEmail(emailId_baseClass);
		logger.info("Entered username");
		
		lp.setPassword(password_baseClass);
		logger.info("Entered password");
		
		lp.clickBtn();
		logger.info("Button is Clicked !!!");
		
		driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
		
		//Contact Back Button 
		
		contactPageObjects cpo = new contactPageObjects(driver);
		cpo.contactLink();
		logger.info("contact side menu Clicked !!!");
		
		
		//Select contact row
		
		cpo.rowHover();
		logger.info("contact row clicked !!!");
		
		driver.findElement(By.xpath("//div[@class='back-home-label']")).click();
		logger.info("contact breadcrum clicked !!!");
		
		String actualMessage = driver.findElement(By.xpath("//h1[@class='title-label float-left']")).getText();
		System.out.println(actualMessage);
		
		String expectedMessage =  "Contacts";
		
		if(actualMessage.equals(expectedMessage)) {
			Assert.assertTrue(true);
			logger.info("Test case passed");
			Thread.sleep(8000);
			driver.close();
			
		}
		else {
			captureScreen(driver,"TC_0038");
			Assert.assertTrue(false);
			reportLog("Test case Failed");
		}
		
		
		
		
	}
	
	
}
