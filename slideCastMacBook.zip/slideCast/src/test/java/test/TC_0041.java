package test;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.loginApp;
import pageObjects.presentationPageObjects;

public class TC_0041 extends baseClass{
// TC_0040: Click on 3 dots button of any slide : Setting Button
	
	
	@Test
	public void presentationSettingButton() throws InterruptedException, IOException {
		
		/*
		Back up script
		 System.setProperty("webdriver.chrome.driver", "/Users/hashstudioz/Desktop/chromedriver");
		WebDriver driver = new ChromeDriver();

		
		driver.get("https://dev.slidecast.com/login");
		driver.manage().window().maximize();
		 */
		
		
//		logger.info("URL is opened");
		
		loginApp lp = new loginApp(driver);
		System.out.println("driver"+driver);
		
		
		lp.mobileRadioClick();
		logger.info("Mobile Radio Button Clicked");
		
		driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
		
		//Login via phone code starts here...
		
		lp.mobileNumbTxtField(mobileNumber_baseClass);
		logger.info("Entered mobile number");
		
		lp.mobilePwdTxtField(password_baseClass);
		logger.info("Entered Password");
		
		lp.mobileSbtBtn();
		logger.info("Mobile button Clicked !!");
		
		driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
		
		
		//Setting Button in presentation starts here.....
		
		presentationPageObjects ppo = new presentationPageObjects(driver);
		ppo.presentationLinkClick();
		logger.info("Presentation button clicked !!");
		ppo.hamicon();
		logger.info("hamburger icon clicked !!");
		ppo.dupeLink();
		logger.info("duplicate link clicked !!");
		ppo.yesButton();
		logger.info("Yes button clicked for duplicate record !!");
		
		//assertion
		
Assert.assertTrue(true);
logger.info("Duplicate record created test case passed !!");
		
	}
	
	
	
	
}
