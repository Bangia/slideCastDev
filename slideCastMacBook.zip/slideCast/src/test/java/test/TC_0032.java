package test;

import java.util.concurrent.TimeUnit;

import org.testng.*;
import org.testng.annotations.Test;

import pageObjects.loginApp;
import pageObjects.settingPageObjects;

public class TC_0032 extends baseClass {
// TC_0032: Guided, Broadcast, & Self-Guided Form Options
	
	@Test
	public void guidedOptions(){
		/*
		Back up script
		 System.setProperty("webdriver.chrome.driver", "/Users/hashstudioz/Desktop/chromedriver");
		WebDriver driver = new ChromeDriver();

		
		driver.get("https://dev.slidecast.com/login");
		driver.manage().window().maximize();
		 */
		
		 logger.info("URL is opened");
			
			loginApp lp = new loginApp(driver);
			lp.setEmail(emailId_baseClass);
			logger.info("Entered username");
			
			lp.setPassword(password_baseClass);
			logger.info("Entered password");
			
			lp.clickBtn();
			logger.info("Button is Clicked !!!");
			
			driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
			
			//Compliance Responses to Text Messaging case starts here
			settingPageObjects spo = new settingPageObjects(driver);
			spo.SettingMenuClic();
			logger.info("Setting tab clicked !!!");
			
			spo.GbsArrowIcon();
	
			logger.info("Guided, Broadcast, & Self-Guided Form Options arrow clicked !!!");
			
			Assert.assertTrue(true);
	
	
	
	
	
	}
	
	
	
	
}
